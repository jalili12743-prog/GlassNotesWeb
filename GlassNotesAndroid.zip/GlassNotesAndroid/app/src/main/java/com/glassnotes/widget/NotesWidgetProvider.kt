package com.glassnotes.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class NotesWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val prefs = context.getSharedPreferences("glass_notes", Context.MODE_PRIVATE)
        appWidgetIds.forEach { widgetId ->
            val views = RemoteViews(context.packageName, R.layout.widget_notes)
            views.setTextViewText(R.id.printing_note, preview(prefs.getString("printing", "")))
            views.setTextViewText(R.id.loan_note, preview(prefs.getString("loan", "")))
            views.setTextViewText(R.id.daily_note, preview(prefs.getString("daily", "")))
            views.setOnClickPendingIntent(R.id.column_printing, editPendingIntent(context, "printing", 101))
            views.setOnClickPendingIntent(R.id.column_loan, editPendingIntent(context, "loan", 102))
            views.setOnClickPendingIntent(R.id.column_daily, editPendingIntent(context, "daily", 103))
            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }

    private fun preview(value: String?): String {
        val note = value?.trim().orEmpty()
        if (note.isEmpty()) return "برای نوشتن لمس کن"
        return if (note.length > 140) note.take(137) + "…" else note
    }

    private fun editPendingIntent(context: Context, category: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra("category", category)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        return PendingIntent.getActivity(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, NotesWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isNotEmpty()) NotesWidgetProvider().onUpdate(context, manager, ids)
        }
    }
}
