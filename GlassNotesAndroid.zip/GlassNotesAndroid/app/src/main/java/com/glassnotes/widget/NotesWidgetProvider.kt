package com.glassnotes.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

class NotesWidgetProvider : AppWidgetProvider() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_TOGGLE_TASK) {
            val category = intent.getStringExtra(EXTRA_CATEGORY) ?: "daily"
            val index = intent.getIntExtra(EXTRA_INDEX, -1)
            val tasks = NoteStorage.load(context, category)
            if (index in tasks.indices) {
                tasks[index] = tasks[index].copy(done = !tasks[index].done)
                NoteStorage.save(context, category, tasks)
                updateAll(context)
            }
            return
        }
        super.onReceive(context, intent)
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { widgetId ->
            val views = RemoteViews(context.packageName, R.layout.widget_notes)

            bindCategory(context, views, "printing", "printing", R.id.add_printing)
            bindCategory(context, views, "loan", "loan", R.id.add_loan)
            bindCategory(context, views, "daily", "daily", R.id.add_daily)

            views.setOnClickPendingIntent(R.id.widget_settings, editIntent(context, "daily", 201))
            views.setOnClickPendingIntent(R.id.widget_title, editIntent(context, "daily", 202))
            views.setOnClickPendingIntent(R.id.widget_edit, editIntent(context, "daily", 203))
            views.setOnClickPendingIntent(R.id.widget_add, editIntent(context, "daily", 204))
            views.setOnClickPendingIntent(R.id.widget_menu, editIntent(context, "daily", 205))

            manager.updateAppWidget(widgetId, views)
        }
    }

    private fun bindCategory(
        context: Context,
        views: RemoteViews,
        category: String,
        prefix: String,
        addButtonId: Int
    ) {
        val tasks = NoteStorage.load(context, category)
        val rowIds = when (prefix) {
            "printing" -> intArrayOf(
                R.id.printing_row_1, R.id.printing_row_2, R.id.printing_row_3,
                R.id.printing_row_4, R.id.printing_row_5, R.id.printing_row_6
            )
            "loan" -> intArrayOf(
                R.id.loan_row_1, R.id.loan_row_2, R.id.loan_row_3,
                R.id.loan_row_4, R.id.loan_row_5, R.id.loan_row_6
            )
            else -> intArrayOf(
                R.id.daily_row_1, R.id.daily_row_2, R.id.daily_row_3,
                R.id.daily_row_4, R.id.daily_row_5, R.id.daily_row_6
            )
        }
        val textIds = when (prefix) {
            "printing" -> intArrayOf(
                R.id.printing_text_1, R.id.printing_text_2, R.id.printing_text_3,
                R.id.printing_text_4, R.id.printing_text_5, R.id.printing_text_6
            )
            "loan" -> intArrayOf(
                R.id.loan_text_1, R.id.loan_text_2, R.id.loan_text_3,
                R.id.loan_text_4, R.id.loan_text_5, R.id.loan_text_6
            )
            else -> intArrayOf(
                R.id.daily_text_1, R.id.daily_text_2, R.id.daily_text_3,
                R.id.daily_text_4, R.id.daily_text_5, R.id.daily_text_6
            )
        }
        val checkIds = when (prefix) {
            "printing" -> intArrayOf(
                R.id.printing_check_1, R.id.printing_check_2, R.id.printing_check_3,
                R.id.printing_check_4, R.id.printing_check_5, R.id.printing_check_6
            )
            "loan" -> intArrayOf(
                R.id.loan_check_1, R.id.loan_check_2, R.id.loan_check_3,
                R.id.loan_check_4, R.id.loan_check_5, R.id.loan_check_6
            )
            else -> intArrayOf(
                R.id.daily_check_1, R.id.daily_check_2, R.id.daily_check_3,
                R.id.daily_check_4, R.id.daily_check_5, R.id.daily_check_6
            )
        }

        rowIds.forEachIndexed { index, rowId ->
            val task = tasks.getOrNull(index)
            if (task == null) {
                // Keep the row's spacing so the three columns remain visually aligned.
                views.setViewVisibility(rowId, View.VISIBLE)
                views.setTextViewText(textIds[index], "")
                views.setViewVisibility(checkIds[index], View.GONE)
            } else {
                views.setViewVisibility(rowId, View.VISIBLE)
                views.setViewVisibility(checkIds[index], View.VISIBLE)
                views.setTextViewText(textIds[index], task.text)
                views.setTextColor(
                    textIds[index],
                    if (task.done) 0xFF718096.toInt() else 0xFF24364A.toInt()
                )
                views.setTextViewText(checkIds[index], if (task.done) "✓" else "○")
                views.setTextColor(
                    checkIds[index],
                    if (task.done) 0xFF239A70.toInt() else 0xFFFFFFFF.toInt()
                )
                views.setOnClickPendingIntent(
                    checkIds[index],
                    toggleIntent(context, category, index)
                )
                views.setOnClickPendingIntent(
                    textIds[index],
                    editIntent(context, category, 300 + category.hashCode().let { kotlin.math.abs(it % 100) } + index)
                )
            }
        }

        views.setOnClickPendingIntent(addButtonId, editIntent(context, category, 400 + category.hashCode().let { kotlin.math.abs(it % 100) }))
    }

    private fun toggleIntent(context: Context, category: String, index: Int): PendingIntent {
        val intent = Intent(context, NotesWidgetProvider::class.java).apply {
            action = ACTION_TOGGLE_TASK
            putExtra(EXTRA_CATEGORY, category)
            putExtra(EXTRA_INDEX, index)
        }
        val requestCode = 1000 + (category.hashCode().let { kotlin.math.abs(it % 100) } * 10) + index
        return PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun editIntent(context: Context, category: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra(EXTRA_CATEGORY, category)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        return PendingIntent.getActivity(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    companion object {
        const val ACTION_TOGGLE_TASK = "com.glassnotes.widget.TOGGLE_TASK"
        const val EXTRA_CATEGORY = "category"
        const val EXTRA_INDEX = "task_index"

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, NotesWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isNotEmpty()) NotesWidgetProvider().onUpdate(context, manager, ids)
        }
    }
}
