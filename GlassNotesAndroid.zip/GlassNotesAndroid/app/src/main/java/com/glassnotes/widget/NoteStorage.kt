package com.glassnotes.widget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class NoteTask(val text: String, val done: Boolean = false)

object NoteStorage {
    private const val PREFS_NAME = "glass_notes"

    private fun tasksKey(category: String) = "tasks_$category"

    fun load(context: Context, category: String): MutableList<NoteTask> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(tasksKey(category), null)
        if (raw == null) {
            val defaults = defaultTasks(category)
            save(context, category, defaults)
            return defaults.toMutableList()
        }

        return try {
            val array = JSONArray(raw)
            MutableList(array.length()) { index ->
                val item = array.optJSONObject(index) ?: JSONObject()
                NoteTask(
                    text = item.optString("text", ""),
                    done = item.optBoolean("done", false)
                )
            }.filter { it.text.isNotBlank() }.toMutableList()
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    fun save(context: Context, category: String, tasks: List<NoteTask>) {
        val array = JSONArray()
        tasks.forEach { task ->
            array.put(JSONObject().put("text", task.text).put("done", task.done))
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(tasksKey(category), array.toString())
            .apply()
    }

    private fun defaultTasks(category: String): List<NoteTask> = when (category) {
        "printing" -> listOf(
            NoteTask("طرح بنر عید نوروز را نهایی کنم."),
            NoteTask("با مشتری آقای احمدی در مورد کارت ویزیت تماس بگیرم."),
            NoteTask("قیمت کاغذ و مقوا استعلام شود."),
            NoteTask("فایل‌های چاپ هفته آینده را آماده کنم."),
            NoteTask("سفارش سررسید را پیگیری کنم.")
        )
        "loan" -> listOf(
            NoteTask("قسط این ماه پرداخت شد.", true),
            NoteTask("پیگیری وام ضروری از بانک"),
            NoteTask("مدارک ضامن را آماده کنم."),
            NoteTask("مبلغ اقساط باقی‌مانده را محاسبه کنم."),
            NoteTask("با بانک برای تسویه زودتر هماهنگ کنم.")
        )
        else -> listOf(
            NoteTask("خرید مواد غذایی برای خانه", true),
            NoteTask("ورزش عصر (پیاده‌روی ۳۰ دقیقه)"),
            NoteTask("مطالعه کتاب (۲۰ صفحه)"),
            NoteTask("تماس با خانواده"),
            NoteTask("مرتب کردن اتاق"),
            NoteTask("برنامه‌ریزی هفته آینده")
        )
    }
}
