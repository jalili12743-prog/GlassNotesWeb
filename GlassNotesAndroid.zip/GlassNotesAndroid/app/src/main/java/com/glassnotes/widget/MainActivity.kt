package com.glassnotes.widget

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var heading: TextView
    private lateinit var editor: EditText
    private var currentKey: String = "printing"
    private val labels = mapOf("printing" to "چاپخانه", "loan" to "وام", "daily" to "روزمره")
    private val prefs by lazy { getSharedPreferences("glass_notes", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(239, 245, 250)
        window.navigationBarColor = Color.rgb(239, 245, 250)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        setContentView(buildUi())
        openCategory(intent.getStringExtra("category") ?: "printing")
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openCategory(intent.getStringExtra("category") ?: currentKey)
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(Color.rgb(239, 245, 250))
        }
        root.addView(TextView(this).apply {
            text = "یادداشت شیشه‌ای"; textSize = 25f
            setTextColor(Color.rgb(34, 48, 64)); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = "برای ویرایش، یکی از بخش‌ها را انتخاب کن."; textSize = 14f
            setTextColor(Color.rgb(91, 108, 126)); gravity = Gravity.RIGHT
            setPadding(0, dp(6), 0, dp(18))
        }, matchWrap())
        heading = TextView(this).apply {
            textSize = 21f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(32, 48, 65)); gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, dp(12))
        }
        root.addView(heading, matchWrap())
        val categories = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        listOf("printing", "loan", "daily").forEach { key ->
            val button = Button(this).apply {
                text = labels[key]; isAllCaps = false; textSize = 13f
                setTextColor(Color.rgb(40, 64, 86))
                background = rounded(Color.WHITE, dp(14), Color.rgb(214, 225, 236))
                setOnClickListener { openCategory(key) }
            }
            val lp = LinearLayout.LayoutParams(0, dp(48), 1f)
            lp.setMargins(dp(3), 0, dp(3), dp(14))
            categories.addView(button, lp)
        }
        root.addView(categories, matchWrap())
        editor = EditText(this).apply {
            hint = "یادداشتت را اینجا بنویس..."; textSize = 17f
            setTextColor(Color.rgb(36, 49, 63)); setHintTextColor(Color.rgb(145, 157, 170))
            gravity = Gravity.TOP or Gravity.RIGHT; textDirection = View.TEXT_DIRECTION_RTL
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 8; setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(Color.WHITE, dp(18), Color.rgb(215, 226, 237))
        }
        root.addView(editor, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(Button(this).apply {
            text = "ذخیره یادداشت"; isAllCaps = false; textSize = 16f
            setTextColor(Color.WHITE); background = rounded(Color.rgb(42, 126, 190), dp(16), Color.rgb(42, 126, 190))
            setOnClickListener { saveNote() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)).apply { topMargin = dp(14) })
        return root
    }

    private fun openCategory(key: String) {
        currentKey = if (labels.containsKey(key)) key else "printing"
        heading.text = "یادداشت ${labels[currentKey]}"
        editor.setText(prefs.getString(currentKey, "") ?: "")
        editor.setSelection(editor.text.length)
    }

    private fun saveNote() {
        prefs.edit().putString(currentKey, editor.text.toString()).apply()
        NotesWidgetProvider.updateAll(this)
        Toast.makeText(this, "یادداشت ذخیره شد", Toast.LENGTH_SHORT).show()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun rounded(fill: Int, radius: Int, stroke: Int) = GradientDrawable().apply {
        setColor(fill); cornerRadius = radius.toFloat(); setStroke(dp(1), stroke)
    }
}
