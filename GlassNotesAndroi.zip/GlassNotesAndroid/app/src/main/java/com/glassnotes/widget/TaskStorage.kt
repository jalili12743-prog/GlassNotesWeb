package com.glassnotes.widget

import android.content.Context

object TaskStorage {
    private const val PREFS_NAME = "glass_notes"
    private const val MAX_TASKS = 5
    private val labels = linkedMapOf(
        "printing" to "چاپخانه",
        "loan" to "وام",
        "daily" to "روزمره"
    )

    data class Task(val text: String, val done: Boolean)

    fun categories(): List<String> = labels.keys.toList()
    fun labelOf(key: String): String = labels[key] ?: key
    fun maxTasks(): Int = MAX_TASKS

    fun loadTasks(context: Context, category: String): MutableList<Task> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(keyFor(category), "").orEmpty()
        if (raw.isBlank()) return mutableListOf()
        return raw.split("\n")
            .mapNotNull { line ->
                if (line.isBlank()) return@mapNotNull null
                val parts = line.split("\t", limit = 2)
                if (parts.size != 2) return@mapNotNull null
                Task(parts[1], parts[0] == "1")
            }
            .toMutableList()
    }

    fun saveTasks(context: Context, category: String, tasks: List<Task>) {
        val safe = tasks.take(MAX_TASKS).map {
            Task(
                text = it.text.replace("\n", " ").replace("\t", " ").trim(),
                done = it.done
            )
        }.filter { it.text.isNotBlank() }
        val encoded = safe.joinToString("\n") { task ->
            (if (task.done) "1" else "0") + "\t" + task.text
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(keyFor(category), encoded)
            .apply()
    }

    fun addTask(context: Context, category: String, text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        val tasks = loadTasks(context, category)
        if (tasks.size >= MAX_TASKS) tasks.removeAt(0)
        tasks.add(Task(clean, false))
        saveTasks(context, category, tasks)
    }

    fun removeLastTask(context: Context, category: String) {
        val tasks = loadTasks(context, category)
        if (tasks.isNotEmpty()) {
            tasks.removeAt(tasks.lastIndex)
            saveTasks(context, category, tasks)
        }
    }

    fun removeTask(context: Context, category: String, index: Int) {
        val tasks = loadTasks(context, category)
        if (index in tasks.indices) {
            tasks.removeAt(index)
            saveTasks(context, category, tasks)
        }
    }

    fun toggleTask(context: Context, category: String, index: Int) {
        val tasks = loadTasks(context, category)
        if (index in tasks.indices) {
            val item = tasks[index]
            tasks[index] = item.copy(done = !item.done)
            saveTasks(context, category, tasks)
        }
    }

    private fun keyFor(category: String): String = "tasks_$category"
}
