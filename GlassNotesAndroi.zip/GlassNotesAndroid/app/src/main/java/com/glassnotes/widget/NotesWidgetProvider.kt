package com.glassnotes.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

class NotesWidgetProvider : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val category = intent.getStringExtra(EXTRA_CATEGORY) ?: return
        when (intent.action) {
            ACTION_TOGGLE_TASK -> {
                val index = intent.getIntExtra(EXTRA_INDEX, -1)
                if (index >= 0) TaskStorage.toggleTask(context, category, index)
            }
            ACTION_REMOVE_LAST -> TaskStorage.removeLastTask(context, category)
            else -> return
        }
        updateAll(context)
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { widgetId ->
            val views = RemoteViews(context.packageName, R.layout.widget_notes)
            bindCategory(context, views, "printing", intArrayOf(
                R.id.printing_task1, R.id.printing_task2, R.id.printing_task3, R.id.printing_task4, R.id.printing_task5
            ), R.id.printing_add, R.id.printing_remove, 100)
            bindCategory(context, views, "loan", intArrayOf(
                R.id.loan_task1, R.id.loan_task2, R.id.loan_task3, R.id.loan_task4, R.id.loan_task5
            ), R.id.loan_add, R.id.loan_remove, 200)
            bindCategory(context, views, "daily", intArrayOf(
                R.id.daily_task1, R.id.daily_task2, R.id.daily_task3, R.id.daily_task4, R.id.daily_task5
            ), R.id.daily_add, R.id.daily_remove, 300)
            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }

    private fun bindCategory(
        context: Context,
        views: RemoteViews,
        category: String,
        taskIds: IntArray,
        addButtonId: Int,
        removeButtonId: Int,
        requestBase: Int
    ) {
        val tasks = TaskStorage.loadTasks(context, category)
        taskIds.forEachIndexed { index, viewId ->
            if (index < tasks.size) {
                val task = tasks[index]
                val prefix = if (task.done) "✓ " else "○ "
                views.setTextViewText(viewId, prefix + task.text)
                views.setTextColor(viewId, if (task.done) 0xFF4A8A63.toInt() else 0xFF233244.toInt())
                views.setViewVisibility(viewId, View.VISIBLE)
                views.setOnClickPendingIntent(viewId, togglePendingIntent(context, category, index, requestBase + index))
            } else {
                if (index == 0) {
                    views.setTextViewText(viewId, "موردی ثبت نشده")
                    views.setTextColor(viewId, 0xFF67798B.toInt())
                    views.setViewVisibility(viewId, View.VISIBLE)
                    views.setOnClickPendingIntent(viewId, addPendingIntent(context, category, requestBase + 90))
                } else {
                    views.setViewVisibility(viewId, View.GONE)
                }
            }
        }
        views.setOnClickPendingIntent(addButtonId, addPendingIntent(context, category, requestBase + 80))
        views.setOnClickPendingIntent(removeButtonId, removePendingIntent(context, category, requestBase + 81))
    }

    private fun addPendingIntent(context: Context, category: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra(EXTRA_CATEGORY, category)
            putExtra("mode", "add")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        return PendingIntent.getActivity(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun removePendingIntent(context: Context, category: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, NotesWidgetProvider::class.java).apply {
            action = ACTION_REMOVE_LAST
            putExtra(EXTRA_CATEGORY, category)
        }
        return PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun togglePendingIntent(context: Context, category: String, index: Int, requestCode: Int): PendingIntent {
        val intent = Intent(context, NotesWidgetProvider::class.java).apply {
            action = ACTION_TOGGLE_TASK
            putExtra(EXTRA_CATEGORY, category)
            putExtra(EXTRA_INDEX, index)
        }
        return PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    companion object {
        private const val ACTION_TOGGLE_TASK = "com.glassnotes.widget.TOGGLE_TASK"
        private const val ACTION_REMOVE_LAST = "com.glassnotes.widget.REMOVE_LAST"
        private const val EXTRA_CATEGORY = "category"
        private const val EXTRA_INDEX = "index"

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, NotesWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isNotEmpty()) NotesWidgetProvider().onUpdate(context, manager, ids)
        }
    }
}
