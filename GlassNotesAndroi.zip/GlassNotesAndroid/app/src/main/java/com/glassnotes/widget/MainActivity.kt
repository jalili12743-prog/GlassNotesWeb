package com.glassnotes.widget

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var heading: TextView
    private lateinit var editor: EditText
    private lateinit var tasksContainer: LinearLayout
    private var currentKey: String = "printing"
    private var startMode: String = "manage"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(227, 233, 239)
        window.navigationBarColor = Color.rgb(227, 233, 239)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        setContentView(buildUi())
        currentKey = intent.getStringExtra("category") ?: "printing"
        startMode = intent.getStringExtra("mode") ?: "manage"
        openCategory(currentKey)
        if (startMode == "add") {
            editor.requestFocus()
            editor.post {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
                imm?.showSoftInput(editor, InputMethodManager.SHOW_IMPLICIT)
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        currentKey = intent.getStringExtra("category") ?: currentKey
        startMode = intent.getStringExtra("mode") ?: "manage"
        openCategory(currentKey)
        if (startMode == "add") editor.requestFocus()
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(18))
            setBackgroundColor(Color.rgb(227, 233, 239))
        }

        root.addView(TextView(this).apply {
            text = "یادداشت شیشه‌ای"
            textSize = 25f
            setTextColor(Color.rgb(34, 48, 64))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, matchWrap())

        root.addView(TextView(this).apply {
            text = "از اینجا می‌تونی مورد جدید اضافه کنی، تیک بزنی یا حذف کنی."
            textSize = 14f
            setTextColor(Color.rgb(86, 102, 117))
            gravity = Gravity.RIGHT
            setPadding(0, dp(6), 0, dp(16))
        }, matchWrap())

        heading = TextView(this).apply {
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(32, 48, 65))
            gravity = Gravity.RIGHT
            setPadding(0, dp(2), 0, dp(10))
        }
        root.addView(heading, matchWrap())

        val categories = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        TaskStorage.categories().forEach { key ->
            val button = Button(this).apply {
                text = TaskStorage.labelOf(key)
                isAllCaps = false
                textSize = 13f
                setTextColor(Color.rgb(40, 64, 86))
                background = rounded(Color.WHITE, dp(14), Color.rgb(197, 208, 220))
                setOnClickListener { openCategory(key) }
            }
            val lp = LinearLayout.LayoutParams(0, dp(46), 1f)
            lp.setMargins(dp(3), 0, dp(3), dp(12))
            categories.addView(button, lp)
        }
        root.addView(categories, matchWrap())

        val addRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        editor = EditText(this).apply {
            hint = "یادداشت جدید..."
            textSize = 16f
            setTextColor(Color.rgb(36, 49, 63))
            setHintTextColor(Color.rgb(145, 157, 170))
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            textDirection = View.TEXT_DIRECTION_RTL
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.WHITE, dp(16), Color.rgb(207, 216, 225))
        }
        addRow.addView(editor, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(8) })
        addRow.addView(Button(this).apply {
            text = "+ افزودن"
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(67, 112, 158), dp(16), Color.rgb(67, 112, 158))
            setOnClickListener { addTask() }
        }, LinearLayout.LayoutParams(dp(112), dp(48)))
        root.addView(addRow, matchWrap())

        root.addView(TextView(this).apply {
            text = "روی هر مورد بزن تا تیک بخورد یا برگردد. برای حذف، دکمه حذف را بزن."
            textSize = 12f
            setTextColor(Color.rgb(99, 110, 121))
            gravity = Gravity.RIGHT
            setPadding(0, dp(10), 0, dp(10))
        }, matchWrap())

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            background = rounded(Color.argb(170, 255, 255, 255), dp(18), Color.rgb(210, 218, 228))
        }
        tasksContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        scroll.addView(tasksContainer, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(Button(this).apply {
            text = "بستن"
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.rgb(44, 63, 84))
            background = rounded(Color.WHITE, dp(16), Color.rgb(200, 211, 222))
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)).apply { topMargin = dp(12) })

        return root
    }

    private fun openCategory(key: String) {
        currentKey = if (TaskStorage.categories().contains(key)) key else "printing"
        heading.text = "مدیریت ${TaskStorage.labelOf(currentKey)}"
        renderTasks()
        editor.setText("")
    }

    private fun renderTasks() {
        tasksContainer.removeAllViews()
        val tasks = TaskStorage.loadTasks(this, currentKey)
        if (tasks.isEmpty()) {
            tasksContainer.addView(TextView(this).apply {
                text = "هنوز موردی اضافه نشده است."
                textSize = 15f
                setTextColor(Color.rgb(117, 128, 139))
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, dp(16), 0, dp(16))
            }, matchWrap())
            return
        }
        tasks.forEachIndexed { index, task ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(10), dp(8))
                background = rounded(Color.argb(150, 255, 255, 255), dp(14), Color.rgb(222, 228, 234))
            }
            val text = TextView(this).apply {
                val prefix = if (task.done) "✓ " else "○ "
                setText(prefix + task.text)
                textSize = 16f
                setTextColor(if (task.done) Color.rgb(74, 133, 95) else Color.rgb(44, 58, 74))
                gravity = Gravity.RIGHT
                textDirection = View.TEXT_DIRECTION_RTL
                setOnClickListener {
                    TaskStorage.toggleTask(this@MainActivity, currentKey, index)
                    NotesWidgetProvider.updateAll(this@MainActivity)
                    renderTasks()
                }
            }
            row.addView(text, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "حذف"
                isAllCaps = false
                textSize = 13f
                setTextColor(Color.WHITE)
                background = rounded(Color.rgb(196, 86, 86), dp(12), Color.rgb(196, 86, 86))
                setOnClickListener {
                    TaskStorage.removeTask(this@MainActivity, currentKey, index)
                    NotesWidgetProvider.updateAll(this@MainActivity)
                    renderTasks()
                }
            }, LinearLayout.LayoutParams(dp(70), dp(38)).apply { rightMargin = dp(8) })
            tasksContainer.addView(row, matchWrap().apply { bottomMargin = dp(8) })
        }
    }

    private fun addTask() {
        val text = editor.text.toString().trim()
        if (text.isBlank()) {
            Toast.makeText(this, "متن یادداشت خالی است", Toast.LENGTH_SHORT).show()
            return
        }
        TaskStorage.addTask(this, currentKey, text)
        editor.setText("")
        NotesWidgetProvider.updateAll(this)
        renderTasks()
        Toast.makeText(this, "یادداشت اضافه شد", Toast.LENGTH_SHORT).show()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun rounded(fill: Int, radius: Int, stroke: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius.toFloat()
        setStroke(dp(1), stroke)
    }
}
